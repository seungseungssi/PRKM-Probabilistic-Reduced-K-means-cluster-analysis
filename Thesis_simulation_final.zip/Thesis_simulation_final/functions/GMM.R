GMM <- function(data, k=4, max.iter = 100, likelihood = T, init_sigma = 1,seed = 1){
    #print("#############################################")
    #print("############### Let's Start #################")
    #print("#############################################")
    #get initial 
    n = nrow(data)
    d = ncol(data)
    set.seed(seed)
    random = sample(1:n, k, replace = F)
    mu = data[random,]
    sigma = init_sigma
    p = matrix(rep(1/k, k), ncol = 1)
    like = 0 
    Partition = sample(1:k, n, replace = T)
    
    for (i in 1:max.iter){
        ########E-step########
        group = unique(Partition)
        pf = matrix(rep(0, k*n), ncol = k)
        # calculate p_k 
        
        for(j in group){
            pf[,j] = dmvnorm(data, mean = mu[j,], sigma = diag(sigma , nrow = d)) * p[j,]
        }
        
        # calculate marginal of pf (nominator)
        sum_pf  = apply(pf,1,sum)
        
        # calculate t_k 
        t = pf/sum_pf
        
        #M-step
        # update the proportion of partition 
        p = as.matrix(apply(t, 2,sum)/nrow(data),ncol = 1)
        
        # update the mu 
        data= as.matrix(data)
        mu = t(t(data)%*%t)/apply(t, 2,sum)
        
        # update the sigma
        sigma_nd = 0
        for (j in 1:k){
            sigma_nd = sigma_nd + sum(t((data-matrix(rep(mu[j,],nrow(data)),nrow = nrow(data), byrow = T))^2) %*% t[,j])
        }
        sigma  = sigma_nd/(n*d)
        
        ###############################
        # Calculate the log-likelihood 
        new_like = 0
        data = as.matrix(data)
        temp = matrix(rep(0, nrow(data)*k), ncol = k)
        for (j in 1:k){
            temp[,j] = dmvnorm(data, mean = mu[j,], sigma = diag(sigma , nrow = d)) * p[j,]
        }
        new_like = sum(log(apply(temp, 1, sum)))
        if (likelihood == T){
            print(paste0(i,"-th iteration"))
            print(new_like)
        }
        # Terminate if the likelihood do not improve
        if (abs(like - new_like)<0.00000001){
            break
        }
        # update the likelihood
        like = new_like
        ################################
    }
    Partition = apply(t, 1, which.max)
    return(list("mu" = mu, "sigma" = sigma, "p" = p, "Partition"=Partition,"Posterior" = t, "Likelihood" =new_like))
}


GMM1 <- function(data, k=4, max.iter = 100, n = 200,likelihood = T, init_sigma = 1,seed = 1){
    #print("#############################################")
    #print("############### Let's Start #################")
    #print("#############################################")
    #get initial
    d = 1
    set.seed(seed)
    random = sample(1:n, k, replace = F)
    mu = data[random]
    sigma = init_sigma
    p = matrix(rep(1/k, k), ncol = 1)
    like = 0 
    Partition = sample(1:k, n, replace = T)
    
    for (i in 1:max.iter){
        ########E-step########
        group = unique(Partition)
        pf = matrix(rep(0, k*n), ncol = k)
        # calculate p_k 
        
        for(j in group){
            pf[,j] = dnorm(data, mean = mu[j], sd = sigma) * p[j,]
        }
        ?rnorm
        # calculate marginal of pf (nominator)
        sum_pf  = apply(pf,1,sum)
        
        # calculate t_k 
        t = pf/sum_pf
        
        #M-step
        # update the proportion of partition 
        p = as.matrix(apply(t, 2,sum)/nrow(data),ncol = 1)
        
        # update the mu 
        data= as.matrix(data)
        mu = t(t(data) %*% t) / apply(t, 2,sum)
        
        # update the sigma
        sigma_nd = 0
        for (j in 1:k){
            sigma_nd = sigma_nd + sum(t((data-matrix(rep(mu[j,],nrow(data)),nrow = nrow(data), byrow = T))^2) %*% t[,j])
        }
        sigma  = sigma_nd/(n*d)
        
        ###############################
        # Calculate the log-likelihood 
        new_like = 0
        data = as.matrix(data)
        temp = matrix(rep(0, nrow(data)*k), ncol = k)
        for (j in 1:k){
            temp[,j] = dnorm(data, mean = mu[j], sd = sigma ) * p[j,]
        }
        new_like = sum(log(apply(temp, 1, sum)))
        if (likelihood == T){
            print(paste0(i,"-th iteration"))
            print(new_like)
        }
        # Terminate if the likelihood do not improve
        if (abs(like - new_like)<0.00000001){
            break
        }
        # update the likelihood
        like = new_like
        ################################
    }
    Partition = apply(t, 1, which.max)
    return(list("mu" = mu, "sigma" = sigma, "p" = p, "Partition"=Partition,"Posterior" = t, "Likelihood" =new_like))
}
