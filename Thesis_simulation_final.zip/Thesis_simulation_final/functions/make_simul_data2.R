library(pracma)

make_simul_data2 <- function(A_sim=factor_loading, c= 3, n = 25, sigma = 1, PSR = 0.15, noise = 9, seed = 1){
    #controls the overlapping
    #c=3; n = 25; sigma = 1; PSR = 0.15;A_sim=factor_loading
    F_sim= t(matrix(c(-c,c), byrow = F, nrow = 1)) #C X Q centroid matrix 
    A_null_sim  = nullspace(t(A_sim)) # J X (J-Q) = 8  X (8-2)
    
    #making the U matix 
    U_sim = matrix(rep(0, n*2*2), ncol = 2) # I X C
    U_sim[1:n,1] = 1;U_sim[(n+1):(2*n),2] = 1
    
    #subspace residual
    set.seed(seed)
    E_sim =matrix(rnorm(n*1*2, mean = 0, sd = sqrt(sigma)), ncol = 1)
    
    #complement residual 
    sigma_ortho = sigma/PSR-sigma
    set.seed(seed+1)
    E_ortho_sim = matrix(rnorm(n*2*noise, mean = 0, sd = sqrt(sigma_ortho)), ncol = noise)
    
    X_sim = U_sim %*% F_sim %*% t(A_sim) + E_sim %*% t(A_sim) + E_ortho_sim%*%t(A_null_sim)
    return(list("X" = X_sim, "U" = U_sim))
}


