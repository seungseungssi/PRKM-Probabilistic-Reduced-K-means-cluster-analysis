rm(list = ls())
#내컴
path = "/Users/iseunghun/Desktop/Simulation_by_date/Thesis_simulation_final"
#윈도우
#path = "C:/Users/stat-pc/Desktop/Thesis_simulationfinal"
#서버
#path = "/home/songjw01/Seung/Thesis_simulationfinal"

source(paste0(path,"/functions/GMM.R"))
source(paste0(path,"/functions/0412PRKM.R"))
source(paste0(path,"/functions/make_simul_data.R"))
#source(paste0(path,"/functions/make_simul_data2.R"))
library(mvtnorm)
library(mclust)
library(clustrd)
library(MixAll)
library(combinat)



restore_init <- function(gmm_path = gmmpath,prkm_path = prkmpath, rep = 10, level = 1, psr = psr){ 
    gmm_ARI = matrix(rep(0, level*rep), nrow = rep)
    prkm_ARI = matrix(rep(0, level*rep), nrow = rep)
    gmm_init = matrix(rep(0, level*rep), nrow = rep)
    prkm_init = matrix(rep(0, level*rep), nrow = rep)
    for (i in 1:rep){
        # EM 
        gmm_temp=  read.csv(paste0(gmm_path,"ARI_",i,"_PSR",psr,".csv"),row.names = 1 )
        prkm_temp=  read.csv(paste0(prkm_path,"ARI_",i,"_PSR",psr,".csv"),row.names = 1 )
        gmm_likeli=  read.csv(paste0(gmm_path,"likeli_",i,"_PSR",psr,".csv"),row.names = 1) 
        prkm_likeli=  read.csv(paste0(prkm_path,"likeli_",i,"_PSR",psr,".csv"),row.names = 1) 
        gmm_likeli_max =apply(gmm_likeli, 2, which.max)
        prkm_likeli_max = apply(prkm_likeli, 2, which.max)
        
        
        
        # get ARI from largest likelihood initials
        
        
        for (j in 1:level){
            gmm_ARI[i,j] = gmm_temp[gmm_likeli_max[j],j]
            prkm_ARI[i,j] = prkm_temp[prkm_likeli_max[j],j]
        }
        
        # get ARI from standard mehtod
        gmm_init[i,] = gmm_likeli_max
        prkm_init[i,] = prkm_likeli_max
        
    }
    gmm_past = data.frame(gmm_init,gmm_ARI)
    prkm_past = data.frame(prkm_init,prkm_ARI)
    return(list("gmm" =gmm_past, "prkm" = prkm_past))
}

partition = prkm$Partition
get_accuracy <- function(k = 4, num_obj = 50, partition=partition){
    list_permu =  permn(1:k)
    list_accu = rep(0, length(list_permu))
    
    for (i in 1:length(list_permu)){
        true = c(rep(list_permu[[i]][1], num_obj), rep(list_permu[[i]][2], num_obj), rep(list_permu[[i]][3], num_obj) , rep(list_permu[[i]][4], num_obj))
        list_accu[i] = sum(diag(table(true, partition)))
    }
    return(max(list_accu)/(k*num_obj))
}

# 고정 
n = 100 ; rep = 20
path = "/Users/iseunghun/Desktop/Simulation_by_date/Thesis_simulation0404/type1/var10/var10_c25/"
########################
psr = 0.2
dist = 2.5
num_var = 10
savepath = "/Users/iseunghun/Desktop/Simulation_by_date/Thesis_simulation_final/type1/var10/var10_c25"
gmmpath  = paste0(path,"0404gmm_c2.5_var10_")
prkmpath = paste0(path,"0404prkm_c2.5_var10_")
ho = restore_init(gmm_path = gmmpath,prkm_path = prkmpath, rep = 10, level = 1, psr = psr)
gmm_past = ho$gmm ; prkm_past = ho$prkm

########1#######
# save path
factor_loading = matrix(c(0.25,0.25,0.25,0.25,0.25,0.25,0.56,0.56,rep(0,num_var-8),
                          0.41,0.41,0.41,-0.41,-0.41,-0.41,0,0, rep(0,num_var-8)), byrow = F, ncol = 2)
# put number of variables
# put number of repetition
num_dataset = 10
# put number of iteration

#empty matrix
prkm_result = matrix(c(rep(0,num_dataset*2)),  ncol =2)
prkm_likeli = matrix(c(rep(0,num_dataset)),  ncol = 1)
gmm_result = matrix(c(rep(0,num_dataset*2)),  ncol =2)
gmm_likeli = matrix(c(rep(0,num_dataset)),  ncol = 1)
## non stat model
kmeans_result = matrix(c(rep(0,num_dataset*2)),  ncol =2)
tandem_kmeans_result = matrix(c(rep(0,num_dataset*2)),  ncol =2)
rkm_result = matrix(c(rep(0,num_dataset*2)),  ncol =2)
real_gmm_const_result = matrix(c(rep(0,num_dataset*2)),  ncol =2)
real_gmm_result = matrix(c(rep(0,num_dataset*2)),  ncol =2)

for (h in 1:num_dataset){
        # clustering
        data = make_simul_data(A_sim=factor_loading, c= dist, n = n, sigma = 1, PSR = psr, noise = num_var-2, seed = h)
        X = scale(data$X)
        cluster = apply(data$U,1, which.max)
    
        # stat model
        # gmm = GMM(X, k = 4, likelihood = F, seed = gmm_past[h,1])
        # prkm = PRKM(X, k=4, max.iter=1000,likelihood = F, init_A="orthogonal", init_eps = 5, seed = prkm_past[h,1], limit = 0.01)
        # 
        # gmm_real_const <- clusterDiagGaussian(data = X, nbCluster = 4, models = "gaussian_pk_s", strategy = clusterStrategy(nbInit = 20))
        # gmm_real <- clusterDiagGaussian(data = X, nbCluster = 4, models = "gaussian_pk_sjk", strategy = clusterStrategy(nbInit = 20))
        # 
        # # 값 저장 
        # prkm_result[h,1] = adjustedRandIndex(prkm$Partition, cluster)
        # prkm_result[h,2] = get_accuracy(k = 4, num_obj = n, partition=prkm$Partition)
        # prkm_likeli[h,1] = gmm$Likelihood
        # gmm_result[h,1] = adjustedRandIndex(gmm$Partition, cluster)
        # gmm_result[h,2] = get_accuracy(k = 4, num_obj = n, partition=gmm$Partition)
        # gmm_likeli[h,1] = gmm$Likelihood
        
        ##standard
        set.seed(1)
        pca_x = princomp(X)$score[,1:2]
        set.seed(1)
        tandem_kmeans = try(kmeans(pca_x, centers = 4, nstart =rep))
        # set.seed(1)
        # kmeans = try(kmeans(X, centers = 4, nstart = rep))
        # rkm = try(cluspca(X, nclus = 4, ndim  = 2, method = "RKM", nstart = rep, seed = 1))
        # rkm_result[h,1] = adjustedRandIndex(rkm$cluster, cluster)
        # rkm_result[h,2] = get_accuracy(k = 4, num_obj = n, partition=rkm$cluster)
        # kmeans_result[h,1] = adjustedRandIndex(kmeans$cluster, cluster)
        # kmeans_result[h,2] = get_accuracy(k = 4, num_obj = n, partition=kmeans$cluster)
        tandem_kmeans_result[h,1] = adjustedRandIndex(tandem_kmeans$cluster, cluster)
        tandem_kmeans_result[h,2] = get_accuracy(k = 4, num_obj = n, partition=tandem_kmeans$cluster)
        # real_gmm_const_result[h,1] = adjustedRandIndex(clusterPredict(X,gmm_real_const)@zi, cluster)
        # real_gmm_const_result[h,2] = get_accuracy(k = 4, num_obj = n,clusterPredict(X,gmm_real_const)@zi)
        # 
        # real_gmm_result[h,1] = adjustedRandIndex(clusterPredict(X,gmm_real)@zi, cluster)
        # real_gmm_result[h,2] = get_accuracy(k = 4, num_obj = n,clusterPredict(X,gmm_real)@zi)
        # print(h)
        
}
#save file
# write.csv(prkm_result,paste0(savepath,"/final_prkm_c",dist,"_var",num_var,"_ARI_",h,"_PSR",psr,".csv"))
# write.csv(prkm_likeli,paste0(savepath,"/final_prkm_c",dist,"_var",num_var,"_Likeli_",h,"_PSR",psr,".csv"))
# write.csv(gmm_result,paste0(savepath,"/final_gmm_c",dist,"_var",num_var,"_ARI_",h,"_PSR",psr,".csv"))
# write.csv(rkm_result,paste0(savepath,"/final_rkm_c",dist,"_var",num_var,"_ARI_",h,"_PSR",psr,".csv"))
write.csv(tandem_kmeans_result,paste0(savepath,"/final_tandem_kmeans_c",dist,"_var",num_var,"_ARI_",h,"_PSR",psr,".csv"))
# write.csv(kmeans_result,paste0(savepath,"/final_kmeans_c",dist,"_var",num_var,"_ARI_",h,"_PSR",psr,".csv"))
# write.csv(real_gmm_result,paste0(savepath,"/final_real_gmm_c",dist,"_var",num_var,"_ARI_",h,"_PSR",psr,".csv"))
# write.csv(real_gmm_const_result,paste0(savepath,"/final_real_gmm_const_c",dist,"_var",num_var,"_ARI_",h,"_PSR",psr,".csv"))

########2#######
psr = 0.25
dist = 2.5
num_var = 10
path = "/Users/iseunghun/Desktop/Simulation_by_date/Thesis_simulation0404/type1/var10/var10_c25/"
gmmpath  = paste0(path,"0404gmm_c2.5_var10_")
prkmpath = paste0(path,"0404prkm_c2.5_var10_")
ho = restore_init(gmm_path = gmmpath,prkm_path = prkmpath, rep = 10, level = 1, psr = psr)
gmm_past = ho$gmm ; prkm_past = ho$prkm


# save path
savepath = "/Users/iseunghun/Desktop/Simulation_by_date/Thesis_simulation_final/type1/var10/var10_c25"
factor_loading = matrix(c(0.25,0.25,0.25,0.25,0.25,0.25,0.56,0.56,rep(0,num_var-8),
                          0.41,0.41,0.41,-0.41,-0.41,-0.41,0,0, rep(0,num_var-8)), byrow = F, ncol = 2)
# put number of variables
# put number of repetition
num_dataset = 10
# put number of iteration

#empty matrix
prkm_result = matrix(c(rep(0,num_dataset*2)),  ncol =2)
prkm_likeli = matrix(c(rep(0,num_dataset)),  ncol = 1)
gmm_result = matrix(c(rep(0,num_dataset*2)),  ncol =2)
gmm_likeli = matrix(c(rep(0,num_dataset)),  ncol = 1)
## non stat model
kmeans_result = matrix(c(rep(0,num_dataset*2)),  ncol =2)
tandem_kmeans_result = matrix(c(rep(0,num_dataset*2)),  ncol =2)
rkm_result = matrix(c(rep(0,num_dataset*2)),  ncol =2)
real_gmm_const_result = matrix(c(rep(0,num_dataset*2)),  ncol =2)
real_gmm_result = matrix(c(rep(0,num_dataset*2)),  ncol =2)

for (h in 1:num_dataset){
    # clustering
    data = make_simul_data(A_sim=factor_loading, c= dist, n = n, sigma = 1, PSR = psr, noise = num_var-2, seed = h)
    X = scale(data$X)
    cluster = apply(data$U,1, which.max)
    
    # # stat model
    # gmm = GMM(X, k = 4, likelihood = F, seed = gmm_past[h,1])
    # prkm = PRKM(X, k=4, max.iter=1000,likelihood = F, init_A="orthogonal", init_eps = 5, seed = prkm_past[h,1], limit = 0.01)
    # 
    # gmm_real_const <- clusterDiagGaussian(data = X, nbCluster = 4, models = "gaussian_pk_s", strategy = clusterStrategy(nbInit = 20))
    # gmm_real <- clusterDiagGaussian(data = X, nbCluster = 4, models = "gaussian_pk_sjk", strategy = clusterStrategy(nbInit = 20))
    # 
    # # 값 저장 
    # prkm_result[h,1] = adjustedRandIndex(prkm$Partition, cluster)
    # prkm_result[h,2] = get_accuracy(k = 4, num_obj = n, partition=prkm$Partition)
    # prkm_likeli[h,1] = gmm$Likelihood
    # gmm_result[h,1] = adjustedRandIndex(gmm$Partition, cluster)
    # gmm_result[h,2] = get_accuracy(k = 4, num_obj = n, partition=gmm$Partition)
    # gmm_likeli[h,1] = gmm$Likelihood
    # 
    # ##standard
    set.seed(1)
    pca_x = princomp(X)$score[,1:2]
    set.seed(1)
    tandem_kmeans = try(kmeans(pca_x, centers = 4, nstart =rep))
    set.seed(1)
    # kmeans = try(kmeans(X, centers = 4, nstart = rep))
    # rkm = try(cluspca(X, nclus = 4, ndim  = 2, method = "RKM", nstart = rep, seed = 1))
    # rkm_result[h,1] = adjustedRandIndex(rkm$cluster, cluster)
    # rkm_result[h,2] = get_accuracy(k = 4, num_obj = n, partition=rkm$cluster)
    # kmeans_result[h,1] = adjustedRandIndex(kmeans$cluster, cluster)
    # kmeans_result[h,2] = get_accuracy(k = 4, num_obj = n, partition=kmeans$cluster)
    tandem_kmeans_result[h,1] = adjustedRandIndex(tandem_kmeans$cluster, cluster)
    tandem_kmeans_result[h,2] = get_accuracy(k = 4, num_obj = n, partition=tandem_kmeans$cluster)
    # real_gmm_const_result[h,1] = adjustedRandIndex(clusterPredict(X,gmm_real_const)@zi, cluster)
    # real_gmm_const_result[h,2] = get_accuracy(k = 4, num_obj = n,clusterPredict(X,gmm_real_const)@zi)
    # 
    # real_gmm_result[h,1] = adjustedRandIndex(clusterPredict(X,gmm_real)@zi, cluster)
    # real_gmm_result[h,2] = get_accuracy(k = 4, num_obj = n,clusterPredict(X,gmm_real)@zi)
    # print(h)
    # 
}
#save file
# write.csv(prkm_result,paste0(savepath,"/final_prkm_c",dist,"_var",num_var,"_ARI_",h,"_PSR",psr,".csv"))
# write.csv(prkm_likeli,paste0(savepath,"/final_prkm_c",dist,"_var",num_var,"_Likeli_",h,"_PSR",psr,".csv"))
# write.csv(gmm_result,paste0(savepath,"/final_gmm_c",dist,"_var",num_var,"_ARI_",h,"_PSR",psr,".csv"))
# write.csv(rkm_result,paste0(savepath,"/final_rkm_c",dist,"_var",num_var,"_ARI_",h,"_PSR",psr,".csv"))
write.csv(tandem_kmeans_result,paste0(savepath,"/final_tandem_kmeans_c",dist,"_var",num_var,"_ARI_",h,"_PSR",psr,".csv"))
# write.csv(kmeans_result,paste0(savepath,"/final_kmeans_c",dist,"_var",num_var,"_ARI_",h,"_PSR",psr,".csv"))
# write.csv(real_gmm_result,paste0(savepath,"/final_real_gmm_c",dist,"_var",num_var,"_ARI_",h,"_PSR",psr,".csv"))
# write.csv(real_gmm_const_result,paste0(savepath,"/final_real_gmm_const_c",dist,"_var",num_var,"_ARI_",h,"_PSR",psr,".csv"))



########3#######
psr = 0.3
dist = 2.5
num_var = 10
path = "/Users/iseunghun/Desktop/Simulation_by_date/Thesis_simulation0404/type1/var10/var10_c25/"
gmmpath  = paste0(path,"0404gmm_c2.5_var10_")
prkmpath = paste0(path,"0404prkm_c2.5_var10_")
ho = restore_init(gmm_path = gmmpath,prkm_path = prkmpath, rep = 10, level = 1, psr = psr)
gmm_past = ho$gmm ; prkm_past = ho$prkm


# save path
savepath = "/Users/iseunghun/Desktop/Simulation_by_date/Thesis_simulation_final/type1/var10/var10_c25"
factor_loading = matrix(c(0.25,0.25,0.25,0.25,0.25,0.25,0.56,0.56,rep(0,num_var-8),
                          0.41,0.41,0.41,-0.41,-0.41,-0.41,0,0, rep(0,num_var-8)), byrow = F, ncol = 2)
# put number of variables
# put number of repetition
num_dataset = 10
# put number of iteration

#empty matrix
prkm_result = matrix(c(rep(0,num_dataset*2)),  ncol =2)
prkm_likeli = matrix(c(rep(0,num_dataset)),  ncol = 1)
gmm_result = matrix(c(rep(0,num_dataset*2)),  ncol =2)
gmm_likeli = matrix(c(rep(0,num_dataset)),  ncol = 1)
## non stat model
kmeans_result = matrix(c(rep(0,num_dataset*2)),  ncol =2)
tandem_kmeans_result = matrix(c(rep(0,num_dataset*2)),  ncol =2)
rkm_result = matrix(c(rep(0,num_dataset*2)),  ncol =2)
real_gmm_const_result = matrix(c(rep(0,num_dataset*2)),  ncol =2)
real_gmm_result = matrix(c(rep(0,num_dataset*2)),  ncol =2)

for (h in 1:num_dataset){
    # clustering
    data = make_simul_data(A_sim=factor_loading, c= dist, n = n, sigma = 1, PSR = psr, noise = num_var-2, seed = h)
    X = scale(data$X)
    cluster = apply(data$U,1, which.max)
    
    # stat model
    # gmm = GMM(X, k = 4, likelihood = F, seed = gmm_past[h,1])
    # prkm = PRKM(X, k=4, max.iter=1000,likelihood = F, init_A="orthogonal", init_eps = 5, seed = prkm_past[h,1], limit = 0.01)
    # 
    # gmm_real_const <- clusterDiagGaussian(data = X, nbCluster = 4, models = "gaussian_pk_s", strategy = clusterStrategy(nbInit = 20))
    # gmm_real <- clusterDiagGaussian(data = X, nbCluster = 4, models = "gaussian_pk_sjk", strategy = clusterStrategy(nbInit = 20))
    # 
    # # 값 저장 
    # prkm_result[h,1] = adjustedRandIndex(prkm$Partition, cluster)
    # prkm_result[h,2] = get_accuracy(k = 4, num_obj = n, partition=prkm$Partition)
    # prkm_likeli[h,1] = gmm$Likelihood
    # gmm_result[h,1] = adjustedRandIndex(gmm$Partition, cluster)
    # gmm_result[h,2] = get_accuracy(k = 4, num_obj = n, partition=gmm$Partition)
    # gmm_likeli[h,1] = gmm$Likelihood
    # 
    ##standard
    set.seed(1)
    pca_x = princomp(X)$score[,1:2]
    set.seed(1)
    tandem_kmeans = try(kmeans(pca_x, centers = 4, nstart =rep))
    # set.seed(1)
    # kmeans = try(kmeans(X, centers = 4, nstart = rep))
    # rkm = try(cluspca(X, nclus = 4, ndim  = 2, method = "RKM", nstart = rep, seed = 1))
    # rkm_result[h,1] = adjustedRandIndex(rkm$cluster, cluster)
    # rkm_result[h,2] = get_accuracy(k = 4, num_obj = n, partition=rkm$cluster)
    # kmeans_result[h,1] = adjustedRandIndex(kmeans$cluster, cluster)
    # kmeans_result[h,2] = get_accuracy(k = 4, num_obj = n, partition=kmeans$cluster)
    tandem_kmeans_result[h,1] = adjustedRandIndex(tandem_kmeans$cluster, cluster)
    tandem_kmeans_result[h,2] = get_accuracy(k = 4, num_obj = n, partition=tandem_kmeans$cluster)
    # real_gmm_const_result[h,1] = adjustedRandIndex(clusterPredict(X,gmm_real_const)@zi, cluster)
    # real_gmm_const_result[h,2] = get_accuracy(k = 4, num_obj = n,clusterPredict(X,gmm_real_const)@zi)
    # 
    # real_gmm_result[h,1] = adjustedRandIndex(clusterPredict(X,gmm_real)@zi, cluster)
    # real_gmm_result[h,2] = get_accuracy(k = 4, num_obj = n,clusterPredict(X,gmm_real)@zi)
    # print(h)
    
}
#save file
# write.csv(prkm_result,paste0(savepath,"/final_prkm_c",dist,"_var",num_var,"_ARI_",h,"_PSR",psr,".csv"))
# write.csv(prkm_likeli,paste0(savepath,"/final_prkm_c",dist,"_var",num_var,"_Likeli_",h,"_PSR",psr,".csv"))
# write.csv(gmm_result,paste0(savepath,"/final_gmm_c",dist,"_var",num_var,"_ARI_",h,"_PSR",psr,".csv"))
# write.csv(rkm_result,paste0(savepath,"/final_rkm_c",dist,"_var",num_var,"_ARI_",h,"_PSR",psr,".csv"))
write.csv(tandem_kmeans_result,paste0(savepath,"/final_tandem_kmeans_c",dist,"_var",num_var,"_ARI_",h,"_PSR",psr,".csv"))
# write.csv(kmeans_result,paste0(savepath,"/final_kmeans_c",dist,"_var",num_var,"_ARI_",h,"_PSR",psr,".csv"))
# write.csv(real_gmm_result,paste0(savepath,"/final_real_gmm_c",dist,"_var",num_var,"_ARI_",h,"_PSR",psr,".csv"))
# write.csv(real_gmm_const_result,paste0(savepath,"/final_real_gmm_const_c",dist,"_var",num_var,"_ARI_",h,"_PSR",psr,".csv"))
# 
# 
